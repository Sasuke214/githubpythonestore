from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import os
import sys
import string
import shutil

no_of_sourcepath=1
source=[[]for i in range(10)]
destination=[[] for i in range(10)]
folder=[str]*10
file=[str]*10
counter=0
source_counter=0
destination_counter=0

tempfolder=''
tempitem=''
temptargetpath=''
#only 1 dest for now
temp2targetpath=''
temppath=[]
tempno_of_sourcepath=0

def ClearAll():
    global no_of_sourcepath,source,destination,folder,file,source_counter,destination_counter
    
    DisableAll()
    txtfname.delete(0,END)
    for i in range(source_counter,0,-1):
        txtsourceEntry[i].destroy()
        txtsourceButton[i].destroy()
        sourceText[i].set("")
        #source[counter].pop(i)
        txtsourceDelete[i-1].destroy()
    sourceText[0].set("")
    txtsourceButton[0].config(state="normal")

    for i in range(destination_counter,0,-1):
        txtdestinationEntry[i].destroy()
        txtdestinationButton[i].destroy()
        destinationText[i].set("")
        #destination[counter].pop(i)
        txtdestinationDelete[i-1].destroy()
    destinationText[0].set("")
    txtdestinationButton[0].config(state="normal")
    

    
    no_of_sourcepath=1
    source_counter=0
    destination_counter=0

def CheckForDirectory(targetpath):
     temp=os.getcwd()
     os.chdir(targetpath)
     if os.path.exists(tempfolder):
       os.chdir(temp)
     else:
       os.makedirs(tempfolder)
       os.chdir(temp)

def NextData():
    global counter
    file[counter]=txtfname.get()
    folder[counter]=file[counter]
    #StoreData()
    ClearAll()
    counter+=1
#def LaunchProgressBar():


def StartOperation():
     global temppath
     global temptargetpath
     global temp2targetpath
     value=0
     print(tempno_of_sourcepath)
     for i in range(0,tempno_of_sourcepath):
            temppath[i]=temppath[i].replace("\\","/")
            temptargetpath=temptargetpath.replace("\\","/")
            print(temppath[i])
            print(temptargetpath)
            CheckForDirectory(temptargetpath)
            temp2targetpath=os.path.join(temptargetpath,tempfolder)
            os.chdir(temppath[i])
            actualdatas=list()
            for root,dirs,files in os.walk(".",topdown=True):
                actualdatas=files
                break
            
            value=SearchForSimilars(actualdatas,value,temppath[i])  
     if value==0:
            print("sorry your file named ",tempitem," cannot be found in the given directory")

def SearchForSimilars(files,value,lpath):
     for f in files:
          f=str(f)  
          if PatternSearch(f,tempitem):
               copyFile(f,lpath)
               value+=1
     return value

def PatternSearch(str1,str2):
       str1=str1.lower()
       str2=str2.lower()
       length2=len(str2)
       length1=len(str1)
     
       for i in range(0,len(str1)):
            j=0
            temp=i
            while j<length2 and i<length1 and str1[i]==str2[j]:
                 i+=1
                 j+=1
            if j==length2:
                 return 1
            else:
                 i=temp
            i+=1
       return 0


def copyFile(fname,lpath):
      localpath=lpath
      localtargetpath=temp2targetpath
      fname=str(fname)
      localpath=os.path.join(lpath,fname)
      localtargetpath=os.path.join(temp2targetpath,fname)
      #os.system("mv"+" "+path+" " + targetpath)
      print("Copying ",fname," from ",lpath," to ",temp2targetpath)
      shutil.copyfile(localpath,localtargetpath)
def MoveFile(fname,lpath):
      localpath=lpath
      localtargetpath=temp2targetpath
      fname=str(fname)
      localpath=os.path.join(lpath,fname)
      localtargetpath=os.path.join(temp2targetpath,fname)
      #os.system("mv"+" "+path+" " + temptargetpath)
      print("Moving ",fname," from ",lpath," to ",temp2targetpath)
      #hutil.move(localpath,localtargetpath)
def DeleteFile(fname,lpath):
      localpath=lpath
      fname=str(fname)
      localpath=os.path.join(lpath,fname)
      #os.system("mv"+" "+path+" " + targetpath)
      print("Removing ",fname," from ",temppath)
      os.remove(localpath)


def GetAllData():

    global tempfolder
    global tempitem
    global temptargetpath
    global temppath
    global tempno_of_sourcepath
    for i in range(0,counter+1):
        tempfolder=folder[i]
        temppath=source[i]
        tempno_of_sourcepath=len(temppath)
        temptargetpath=destination[i][0]
        tempitem=file[i]
        StartOperation()
               

def CopyData():
    file[counter]=txtfname.get()
    folder[counter]=file[counter]
    GetAllData()
    #LaunchProgressBar() 

    
def EnableAll():
    buttonnext.config(state='normal')
    buttonsave.config(state='normal')
    buttoncopy.config(state='normal')
    buttonmove.config(state='normal')

def DisableAll():
    buttonnext.config(state=DISABLED)
    buttonsave.config(state=DISABLED)
    buttoncopy.config(state=DISABLED)
    buttonmove.config(state=DISABLED)

def Exit():
    fp.close()
    root.destroy()
    
def StoreData():
    global counter
    if counter!=0:
        fp.write("\n")
    file[counter]=txtfname.get()
    folder[counter]=file[counter]
    fp.write(folder[counter]+"     ")
    for i in range(0,source_counter+1):
      fp.write(source[counter][i]+"    ")
    fp.write(" ")
    for i in range(0,destination_counter+1):
      fp.write(destination[counter][i]+"    ")
    fp.write(" ")
    fp.write(file[counter])

def PrintAll():
    for i in range(0,counter+1):
        print('break')
        print(folder[i])
        print(file[i])
        for j in range(0,len(source[i])):
            print(source[i][j])
        print('dest:\n')
        for j in range(0,len(destination[i])):
            print(destination[i][j]) 

def Print():
    global file
    global folder
    print(counter)
    file[counter]=txtfname.get()
    folder[counter]=txtfname.get()
    print(folder[counter])
    print(file[counter])
    for i in range(0,source_counter+1):
        print(source[counter][i])
    print('dest:')
    for i in range(0,destination_counter+1):
        print(destination[counter][i])

def SelectingSourceFile():
    global source
    #getting the folder location for searching 
    path=filedialog.askopenfilename()

    #striping selected file from location
    f=path.rfind('/')
    man=path[:f]
    if len(source[counter])>source_counter:
        source[counter].pop(source_counter)

    source[counter].append(man)
    sourceText[source_counter].set(man)

    if txtfname.get()!="" and sourceText[source_counter].get()!="" and destinationText[destination_counter].get()!="":
        EnableAll()
    
def SelectingDestinationFile():
    if txtfname.get()=="":
        messagebox.showerror("Error","Please Enter File Name")
        return
    
    global destination
    #getting the folder location for searching 
    path=filedialog.askopenfilename()

    #striping selected file from location
    f=path.rfind('/')
    man=path[:f]

    if len(destination[counter])>destination_counter:
        destination[counter].pop(destination_counter)
    
    destination[counter].append(man)
    destinationText[destination_counter].set(man)

    if txtfname.get()!="" and sourceText[source_counter].get()!="" and destinationText[destination_counter].get()!="":
        EnableAll()

def DeleteCurrentSource():
    global source_counter
    #for source input box
    txtsourceEntry[source_counter].destroy()
    #for source select button
    txtsourceButton[source_counter].destroy()
    sourceText[source_counter].set("")
    source[counter].pop(source_counter)
    txtsourceDelete[source_counter-1].destroy()

    source_counter-=1
    
    txtsourceButton[source_counter].config(state="normal")
    
def AddNewSource():
    global source_counter

    if sourceText[source_counter].get()=="":
        return
    txtsourceButton[source_counter].config(state=DISABLED)
    source_counter+=1
    
    #for source input box
    txtsourceEntry[source_counter]=Entry(frame1,state="readonly",textvariable=sourceText[source_counter])
    #for source select button
    txtsourceButton[source_counter]=Button(frame1,text="Select",command=SelectingSourceFile)
    #for deleting current source button
    txtsourceDelete[source_counter-1]=Button(frame1,text="-",command=DeleteCurrentSource)
    #arranging file source elements
    txtsourceEntry[source_counter].grid(row=source_counter+1)
    txtsourceButton[source_counter].grid(row=source_counter+1,column=1)
    txtsourceDelete[source_counter-1].grid(row=source_counter+1,column=2)
    
def DeleteCurrentDestination():
    global destination_counter
    #for destination input box
    txtdestinationEntry[destination_counter].destroy()
    #for destination select button
    txtdestinationButton[destination_counter].destroy()
    destinationText[destination_counter].set("")
    destination[counter].pop(destination_counter)
    txtdestinationDelete[destination_counter-1].destroy()

    destination_counter-=1
    txtdestinationButton[destination_counter].config(state="normal")
    
def AddNewDestination():
    return
    global destination_counter
    if destinationText[destination_counter].get()=="":
        return
    txtdestinationButton[destination_counter].config(state=DISABLED)
    destination_counter+=1
    #for destination input box
    txtdestinationEntry[destination_counter]=Entry(frame2,state="readonly",textvariable=destinationText[destination_counter])
    #for destination select button
    txtdestinationButton[destination_counter]=Button(frame2,text="Select",command=SelectingDestinationFile)
    #for deleting destination button
    txtdestinationDelete[destination_counter-1]=Button(frame2,text="-",command=DeleteCurrentDestination)

    #arranging file destination elements
    txtdestinationEntry[destination_counter].grid(row=destination_counter+1)
    txtdestinationButton[destination_counter].grid(row=destination_counter+1,column=1)
    txtdestinationDelete[destination_counter-1].grid(row=destination_counter+1,column=2)



#opening a file
fp=open('data.txt','w+')

#setting root for GUIS
root=Tk()

txtsourceEntry=[None]*10
txtsourceButton=[None]*10
txtsourceAdd=[None]*10
txtsourceDelete=[None]*10
sourceText=[]

txtdestinationEntry=[None]*10
txtdestinationButton=[None]*10
txtdestinationAdd=[None]*10
txtdestinationDelete=[None]*10
destinationText=[]

for i in range(0,10):
    sourceText.append(StringVar())
    destinationText.append(StringVar())
    sourceText[i].set("")
    destinationText[i].set("")
    


frame0=Frame(root)
frame1=Frame(root)
frame2=Frame(root)
frame3=Frame(root)

frame0.grid(row=1)
frame1.grid(row=2)
frame2.grid(row=3)
frame3.grid(row=4)

#for filename label
lblfname=Label(frame0,text="File Name")
txtfname=Entry(frame0)

#Arranging the filename elements
lblfname.grid(row=0)
txtfname.grid(row=1)


#for source label
lblsource=Label(frame1,text="Source")
#for source input box
txtsourceEntry[0]=Entry(frame1,state="readonly",textvariable=sourceText[0])
#for source select button
txtsourceButton[0]=Button(frame1,text="Select",command=SelectingSourceFile)
#for adding new source button
txtsourceAdd[0]=Button(frame1,text="+",command=AddNewSource)

#arranging file source elements
lblsource.grid(row=0)
txtsourceEntry[0].grid(row=1)
txtsourceButton[0].grid(row=1,column=1)
txtsourceAdd[0].grid(row=1,column=2)

#for destination label
lbldestination=Label(frame2,text="Destination")
#for destination input box
txtdestinationEntry[0]=Entry(frame2,state="readonly",textvariable=destinationText[0])
#for destination select button
txtdestinationButton[0]=Button(frame2,text="Select",command=SelectingDestinationFile)
#for adding new destination button
txtdestinationAdd[0]=Button(frame2,text="+",command=AddNewDestination)

#arranging file destination elements
lbldestination.grid(row=0)
txtdestinationEntry[0].grid(row=1)
txtdestinationButton[0].grid(row=1,column=1)
txtdestinationAdd[0].grid(row=1,column=2)

#adding next save copy move and cancel
buttonnext=Button(frame3,text=">>",command=NextData)
buttonsave=Button(frame3,text="Save",command=StoreData)
buttoncopy=Button(frame3,text="Copy",command=CopyData)
buttonmove=Button(frame3,text="Move")
buttoncancel=Button(frame3,text="Clear",command=ClearAll)

#Arranging
buttonnext.grid(row=0,column=0,sticky=N)
buttonsave.grid(row=0,column=1,sticky=N)
buttoncopy.grid(row=0,column=2,sticky=N)
buttonmove.grid(row=0,column=3,sticky=N)
buttoncancel.grid(row=0,column=4,sticky=N)

DisableAll()


#For Exit
root.protocol("WM_DELETE_WINDOW",Exit)

root.mainloop()


















